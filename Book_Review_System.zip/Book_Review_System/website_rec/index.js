import express from "express";
import bodyParser from "body-parser" ;
import { dirname } from "path";
import { fileURLToPath } from "url";
import pg from "pg" ;
import { exec } from 'child_process';
import { promisify } from 'util';
import { spawn } from 'child_process';


// CONNECTING DATABASE
const __dirname = dirname(fileURLToPath(import.meta.url));

const db = new pg.Client({
  user: "postgres" ,
  database: "railway" ,
  password: "*B1AcCDbDegA4DD5DfB*C-fG5a6-c1e6" ,
  host : "roundhouse.proxy.rlwy.net" ,
  port: 55650
}) ;


  // Convert exec to a promise-based function
const execPromise = promisify(exec);


db.connect() ;

// RUNNING SERVER AND FORM

const app = express();
const port = 3000 ; 


app. listen(process.env.PORT || port, ( ) =>
{ console.log(` Server running on port ${port}.`) ;
})

app.use(express.urlencoded({ extended: true }));


// HOMEPAGE

app.get("/", (req, res) => {
  res.render(__dirname + "/views/index.ejs");
  });

// DATAENTRY FORM
app.get("/enter_data" , (req, res) => {
   res.render(__dirname + "/views/enter_data.ejs");
  });


  // Entering  customer get stockcode page . 
  app.post("/get_for_customer", (req, res) => {
    const User_ID = req.body.User_ID ;  
    const sqlQuery = 'SELECT "book1", "book2", "book3" FROM "rec_books" WHERE "User-ID" = $1';
    db.query(sqlQuery, [User_ID], (err, result) => {
      if (err) {
        let ret_satus = " Can not retrieve from data base"     // Handle errors as needed
      } else {
        // Rows will contain the result of the query
        let ret_status = " Recommended books retrieved succesfully . "
        console.log("awesome")
        const rows = result.rows;
        console.log(rows.length)
        if (rows.length === 0 ){
          let ret_status = " No such user found ."
          res.render(__dirname + "/views/show_result.ejs" , 
         {
             stock_b : " No such user found . No books to recommend" ,
             database : " " ,
             retrieve : ret_status ,
             stock_a : "" ,
             
             stock_c : ""
   
         })
         }
         else{ 
   
   
         //let stock1 = rows[0].stockcode
         //let stock2 = rows[0].bestsale2nd
         //let stock3 = rows[0].bestsale3rd 
         
         
         res.render("show_result.ejs" , 
         {
             stock_b : rows[0].book2 ,
             database : " " ,
             retrieve : ret_status ,
             stock_a : rows[0].book1 ,
             
             stock_c : rows[0].book3 
   
         })
       }}
     }            
     
   );   
  })



  // Get customer id from stock page
  app.post("/get_for_stockcode", (req, res) => { 
    const ISBN = req.body.ISBN;
    const sqlQuery = 'SELECT "User-ID" FROM "rec_books" WHERE "book1" = $1 or "book2" = $1 or "book3" = $1 '
    db.query(sqlQuery, [ISBN], (err, result) => {
      if (err) {
        let ret_satus = " Can not retrieve from data base"     // Handle errors as needed
      } else {
        // Rows will contain the result of the query
        let ret_status = " list of users retrieved succesfully . "
        console.log("awesome")
        const rows = result.rows;
        console.log(result) ;
        console.log(rows) ; 
        res.render(__dirname + "/views/dis_cust.ejs" , { dataArray: rows })

      }})})



// DATA INSERTION FORM AND EXECUTION
// DATA INSERTION FORM AND EXECUTION
app.post("/submit", (req, res) => {
  console.log(req.body);
  const User_ID = req.body.User_ID;
  const isbn = req.body.isbn;
  const Book_Rating = req.body.Book_Rating;
 
  let data_stat = "Data inserted succesfully"

  db.query(
    'INSERT INTO final_book_rating("User-ID" ,"ISBN", "Book-Rating") VALUES( $1 , $2, $3)',
    [User_ID, isbn, Book_Rating ],
    (err, result) => {
      if (err) {
        let data_stat = err
      } else {
        
      }
    }
  );
  
  // DISPLAYING THE OUTPUT FOR THE DATA INSERT 
  // Your SQL query to select rows based on a condition
  const sqlQuery = 'SELECT "book1", "book2", "book3" FROM "rec_books" WHERE "User-ID" = $1';
  db.query(sqlQuery, [User_ID], (err, result) => {
    if (err) {
      let ret_satus = " Can not retrieve from data base"     // Handle errors as needed
    } else {
      // Rows will contain the result of the query
      let ret_status = " Recommended books retrieved succesfully . "
      console.log("awesome")
      const rows = result.rows;
      console.log(rows.length)
      

      if (rows.length === 0 ){
       let ret_status = " New user . Can not recommend as no past history ."
       res.render(__dirname + "/views/shw_result_new.ejs" , 
      {
          stock_b1 : " New user . No books to recommend" ,
          database : data_stat ,
          retrieve : ret_status ,
          stock_a1 : "" ,
          
          stock_c1 : ""

      })
      } 
     else{
        res.render(__dirname + "/views/show_result.ejs" , 
      {
          stock_b : rows[0].book2 ,
          database : data_stat ,
          retrieve : ret_status ,
          stock_a : rows[0].book1 ,
          
          stock_c : rows[0].book3 

      })}
    }
  }            
  
);
        
}); // <-- Corrected closing parenthesis


// TRAINING Data selectin
app.get("/Get_data" , (req, res) => {
  res.render(__dirname + "/views/Get_data.ejs");
 });

   
// TRAINING PATH SELECTION
app.get("/train" , (req, res) => {
  res.render(__dirname + "/views/train_model_form.ejs");
 });

